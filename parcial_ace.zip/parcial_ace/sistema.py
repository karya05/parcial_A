import sqlite3

conexion = sqlite3.connect("inventario.db")
conexion.execute("PRAGMA foreign_keys = ON")
cursor = conexion.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS productos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    precio REAL NOT NULL CHECK(precio >= 0),
    cantidad INTEGER NOT NULL CHECK(cantidad >= 0)
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS ventas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    producto_id INTEGER NOT NULL,
    cantidad INTEGER NOT NULL CHECK(cantidad > 0),
    FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE RESTRICT
)
""")
conexion.commit()


def registrar_producto():
    nombre = input("nombre: ").strip()

    try:
        precio = float(input("precio: "))
        cantidad = int(input("cantidad disponible: "))

        if not nombre or precio < 0 or cantidad < 0:
            print("datos no validos.")
            return

        cursor.execute(
            "INSERT INTO productos (nombre, precio, cantidad) VALUES (?, ?, ?)",
            (nombre, precio, cantidad)
        )
        conexion.commit()
        print("producto registrado.")

    except ValueError:
        print("el precio o la cantidad no son validos.")
    except sqlite3.Error as error:
        conexion.rollback()
        print("error:", error)


def consultar_productos():
    cursor.execute(
        "SELECT id, nombre, precio, cantidad FROM productos ORDER BY id"
    )
    productos = cursor.fetchall()

    if not productos:
        print("no hay productos registrados.")

    for producto in productos:
        print(producto)


def actualizar_producto():
    try:
        producto_id = int(input("id del producto: "))
        print("1. actualizar precio")
        print("2. actualizar cantidad")
        opcion = input("opcion: ")

        if opcion == "1":
            precio = float(input("nuevo precio: "))

            if precio < 0:
                print("el precio no puede ser negativo.")
                return

            cursor.execute(
                "UPDATE productos SET precio = ? WHERE id = ?",
                (precio, producto_id)
            )

        elif opcion == "2":
            cantidad = int(input("nueva cantidad: "))

            if cantidad < 0:
                print("la cantidad no puede ser negativa.")
                return

            cursor.execute(
                "UPDATE productos SET cantidad = ? WHERE id = ?",
                (cantidad, producto_id)
            )

        else:
            print("opcion no valida.")
            return

        if cursor.rowcount == 0:
            print("no existe un producto con ese id.")
        else:
            conexion.commit()
            print("producto actualizado.")

    except ValueError:
        print("ingresa valores numericos validos.")
    except sqlite3.Error as error:
        conexion.rollback()
        print("error:", error)


def eliminar_producto():
    try:
        producto_id = int(input("id del producto: "))

        cursor.execute(
            "DELETE FROM productos WHERE id = ?",
            (producto_id,)
        )

        if cursor.rowcount == 0:
            print("no existe un producto con ese id.")
        else:
            conexion.commit()
            print("producto eliminado.")

    except ValueError:
        print("el id debe ser numerico.")
    except sqlite3.IntegrityError:
        conexion.rollback()
        print("no se puede eliminar: el producto tiene ventas registradas.")
    except sqlite3.Error as error:
        conexion.rollback()
        print("error:", error)


def registrar_venta():
    try:
        producto_id = int(input("id del producto: "))
        cantidad = int(input("cantidad a vender: "))

        if cantidad <= 0:
            print("la cantidad debe ser mayor que cero.")
            return

        cursor.execute(
            "SELECT cantidad FROM productos WHERE id = ?",
            (producto_id,)
        )
        producto = cursor.fetchone()

        if producto is None:
            print("el producto no existe.")
            return

        if producto[0] < cantidad:
            print("no hay suficientes unidades.")
            return

        try:
            cursor.execute("BEGIN")

            cursor.execute(
                "INSERT INTO ventas (producto_id, cantidad) VALUES (?, ?)",
                (producto_id, cantidad)
            )

            cursor.execute(
                "UPDATE productos SET cantidad = cantidad - ? WHERE id = ?",
                (cantidad, producto_id)
            )

            conexion.commit()
            print("venta registrada y existencias actualizadas.")

        except sqlite3.Error as error:
            conexion.rollback()
            print("error en la venta. se cancelaron los cambios:", error)

    except ValueError:
        print("ingresa un id y una cantidad validos.")
    except sqlite3.Error as error:
        conexion.rollback()
        print("error:", error)


def historial_ventas():
    cursor.execute("""
        SELECT ventas.id, productos.nombre, ventas.cantidad
        FROM ventas
        JOIN productos ON ventas.producto_id = productos.id
        ORDER BY ventas.id
    """)

    ventas = cursor.fetchall()

    if not ventas:
        print("no hay ventas registradas.")

    for venta in ventas:
        print(venta)


def probar_rollback():
    try:
        producto_id = int(input("id del producto para la prueba: "))
        cantidad = int(input("cantidad de prueba: "))

        if cantidad <= 0:
            print("la cantidad debe ser mayor que cero.")
            return

        cursor.execute(
            "SELECT cantidad FROM productos WHERE id = ?",
            (producto_id,)
        )
        producto = cursor.fetchone()

        if producto is None or producto[0] < cantidad:
            print("producto inexistente o inventario insuficiente.")
            return

        cantidad_inicial = producto[0]

        cursor.execute("SELECT COUNT(*) FROM ventas")
        ventas_iniciales = cursor.fetchone()[0]

        cursor.execute("BEGIN")

        cursor.execute(
            "INSERT INTO ventas (producto_id, cantidad) VALUES (?, ?)",
            (producto_id, cantidad)
        )

        try:
            raise RuntimeError("error controlado para probar rollback")

        except RuntimeError as error:
            conexion.rollback()

            cursor.execute(
                "SELECT cantidad FROM productos WHERE id = ?",
                (producto_id,)
            )
            cantidad_final = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM ventas")
            ventas_finales = cursor.fetchone()[0]

            print(error)
            print("inventario antes:", cantidad_inicial)
            print("inventario despues:", cantidad_final)
            print("ventas antes:", ventas_iniciales)
            print("ventas despues:", ventas_finales)
            print("resultado esperado: inventario y ventas quedan iguales.")

    except ValueError:
        print("ingresa valores numericos validos.")
    except sqlite3.Error as error:
        conexion.rollback()
        print("error:", error)


def menu():
    while True:
        print("""
--- sistema de inventario y ventas ---
1. registrar producto
2. consultar productos
3. actualizar producto
4. eliminar producto
5. registrar venta
6. historial de ventas
7. probar rollback
0. salir
""")

        opcion = input("selecciona una opcion: ")

        if opcion == "1":
            registrar_producto()
        elif opcion == "2":
            consultar_productos()
        elif opcion == "3":
            actualizar_producto()
        elif opcion == "4":
            eliminar_producto()
        elif opcion == "5":
            registrar_venta()
        elif opcion == "6":
            historial_ventas()
        elif opcion == "7":
            probar_rollback()
        elif opcion == "0":
            break
        else:
            print("opcion no valida.")


try:
    menu()
finally:
    conexion.close()